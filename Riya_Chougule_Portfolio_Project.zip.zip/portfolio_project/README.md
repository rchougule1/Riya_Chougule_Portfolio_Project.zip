# Riya Chougule - Personal Portfolio

A responsive multi-page personal portfolio created for Minor Project 01.

## Pages
- Home
- About
- Skills
- Projects
- Contact

## Technologies
- HTML5
- CSS3
- JavaScript
- Git
- GitHub

## Run locally
Open `index.html` in a browser, or use VS Code Live Server.

## Customize
1. Replace the `RC` placeholder in the profile section with your photo.
2. Add your LinkedIn and GitHub URLs in `contact.html`.
3. Update project descriptions and skills as your experience grows.

## GitHub
```bash
git init
git add .
git commit -m "Create personal portfolio"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/riya-portfolio.git
git push -u origin main
```
