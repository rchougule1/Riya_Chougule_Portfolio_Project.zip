# PulseX Smartwatch – Responsive Product Landing Page

## Minor Project 02 – Web Development

A modern, responsive product landing page created for a smartwatch product called **PulseX**.

### Technologies Used
- HTML5
- CSS3
- Tailwind CSS
- Flexbox
- CSS Grid
- JavaScript

### Sections
1. Navigation Bar
2. Hero Section
3. Product Features
4. Benefits / Unique Selling Points
5. Customer Reviews
6. Pricing / Call to Action
7. Footer

### Responsive Design
The page is designed for:
- Mobile
- Tablet
- Desktop

### How to Run
1. Download or clone the repository.
2. Open `index.html` in a web browser.
3. Internet access is required for the Tailwind CSS CDN.

### Project Structure
```text
PulseX-Smartwatch-Landing-Page/
├── index.html
└── README.md
```

## Note
This is an educational minor project demonstrating responsive web design and modern CSS concepts.
